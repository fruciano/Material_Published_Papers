### This is a placeholder for the R code used in
### Jones et al. - Insectes Sociaux